'''
seqlibJaJa

A library for working with DNA sequences - supports operations such as reading from FASTA files,
reverse complement computation, and slicing sequences using GenBank notation. 
The project was developed by the PP4B team at Jagiellonian University.
'''

from seqlibJaJa.Seq import DNAseq

__version__ = '0.1.0'
__license__ = 'GPL-3.0-or-later'
__status__  = 'beta'
__author__  = 'First1 Last1'
__email__   = 'first.last.1@somewhere.io'
__credits__ = [ 'Jagiellonian University, Krakow, Poland', 'PP4B Team' ]

__all__ = [
    '__version__',
    '__license__',
    '__status__',
    '__author__',
    '__email__',
    '__creadits__',
    'DNAseq'
]

