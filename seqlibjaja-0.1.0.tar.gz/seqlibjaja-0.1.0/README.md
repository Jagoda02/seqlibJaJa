# The library overview
The `seqlibJaJa` library provides tools for handling DNA sequences. This library aims to simplify DNA sequence analysis tasks such as reading, manipulating, and querying biological sequences in Python.


# Library installation using _pip_
Installation of the `seqlibJaJa` library with pip is quite straightforward:
```Bash
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple seqlibJaJa
```

# A quick example of the library usage
Learn how to use the `seqlibJaJa` library with examples provided below.

```Python
# Import the DNAseq class from the seqlibJaJa library
from seqlibJaJa import DNAseq

# Example 1: Load a sequence from a file
seqs = DNAseq.from_file('path_to_file.fasta')
print(seqs)

# Example 2: Access a specific sequence by index
sequence = seqs['seq1']
print(sequence)

# Example 3: Get the reverse complement of a sequence
rev_seq = sequence.revcmpl()
print(rev_seq)
```

# The `DNAseq` class in details
The DNAseq class is used for representing and manipulating DNA sequences. It includes various methods for initializing objects, reading sequences from FASTA files, performing reverse complement operations, slicing sequences according to GenBank notation, and more.

## Initialisation
The DNAseq class is initialized with three parameters:
- seqid (str): The identifier for the sequence.
- title (str): The title of the sequence, if provided.
- seq (str): The actual DNA sequence as a string.
Example of initialization:
seq = DNAseq(seqid="seq1", title="Sample Sequence", seq="ATGCATGC")

## Methods
- __init__(self, seqid, title, seq) - Initializes a new DNAseq object with the provided seqid, title, and seq. Returns a new DNAseq object.
- __repr__(self) - Returns a string representation of the sequence, showing the first 10 bases followed by '...'.
- __len__(self) - Returns the length of the sequence.
- __str__(self) - Returns the sequence, formatted with a line break every 60 characters.
- revcmpl(self) - Returns a new DNAseq object with the reverse complement of the sequence.
- from_file(cls, filepath) - Class method that reads a FASTA file and returns a dictionary of DNAseq objects.
- __getitem__(self, key) - Allows indexing or slicing the sequence using GenBank notation.
- __add__(self, other) - Adds two DNAseq objects together, concatenating their sequences and combining their seqid and title.
- copy(self) - Returns a copy of the DNAseq object.

## Indexing and slicing
You can index or slice a DNAseq object, but with GenBank indexing rules:
- Indexing starts at 1 (not 0).
- Slicing is inclusive, meaning both start and end indices are included.
- If the start index is greater than the end, the reverse complement of the sequence is returned.

## Adding two sequences
seq1 = DNAseq(seqid="seq1", title="First", seq="ATGC")
seq2 = DNAseq(seqid="seq2", title="Second", seq="GCAT")
combined = seq1 + seq2
print(combined.seq)  
## Output: ATGCGCAT

